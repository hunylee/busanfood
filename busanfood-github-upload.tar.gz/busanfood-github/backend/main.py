import os
import sqlite3
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
DB_PATH = "/workspace/data/app.db"
def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn
def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS favorites (
          restaurant_id TEXT PRIMARY KEY,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS search_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          query TEXT NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS preferences (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
        """)
app = FastAPI()
init_db()
class SearchBody(BaseModel):
    query: str
class PreferenceBody(BaseModel):
    key: str
    value: str
BASE_SELECT = """
SELECT
  e.UC_SEQ AS id,
  COALESCE(NULLIF(TRIM(e.MAIN_TITLE), ''), NULLIF(TRIM(e.TITLE), ''), '이름 미상') AS name,
  TRIM(COALESCE(e.GUGUN_NM, '')) AS district,
  TRIM(COALESCE(e.ADDR1, '')) AS address,
  TRIM(COALESCE(e.ADDR2, '')) AS address_detail,
  TRIM(COALESCE(e.RPRSNTV_MENU, '')) AS menu,
  TRIM(COALESCE(e.ITEMCNTNTS, '')) AS description,
  TRIM(COALESCE(e.CNTCT_TEL, '')) AS phone,
  TRIM(COALESCE(e.USAGE_DAY_WEEK_AND_TIME, '')) AS hours,
  TRIM(COALESCE(e.HOMEPAGE_URL, '')) AS homepage_url,
  TRIM(COALESCE(e.MAIN_IMG_THUMB, '')) AS image_url,
  CAST(e.LAT AS REAL) AS lat,
  CAST(e.LNG AS REAL) AS lng,
  CASE WHEN f.restaurant_id IS NULL THEN 0 ELSE 1 END AS favorite
FROM external_data e
LEFT JOIN favorites f ON f.restaurant_id = e.UC_SEQ
WHERE TRIM(COALESCE(e.UC_SEQ, '')) <> ''
  AND TRIM(COALESCE(e.LAT, '')) <> ''
  AND TRIM(COALESCE(e.LNG, '')) <> ''
"""
@app.get('/api/health')
def health():
    return {'ok': True}
@app.get('/api/restaurants')
def restaurants(
    query: str = '',
    favorites_only: bool = False,
    limit: int = Query(default=500, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    keywords = f"%{query.strip()}%"
    sql = BASE_SELECT
    params = []
    if query.strip():
        sql += """ AND (
          e.MAIN_TITLE LIKE ? OR e.TITLE LIKE ? OR e.GUGUN_NM LIKE ? OR
          e.ADDR1 LIKE ? OR e.RPRSNTV_MENU LIKE ? OR e.ITEMCNTNTS LIKE ?
        )"""
        params.extend([keywords] * 6)
    if favorites_only:
        sql += " AND f.restaurant_id IS NOT NULL"
    sql += " ORDER BY e.GUGUN_NM COLLATE NOCASE, e.MAIN_TITLE COLLATE NOCASE LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    with get_db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {'items': [dict(row) for row in rows], 'limit': limit, 'offset': offset}
@app.get('/api/restaurants/translations')
def restaurant_translations(lang: str = Query(..., pattern='^(en|ja)$')):
    name_column = 'name_en' if lang == 'en' else 'name_ja'
    with get_db() as conn:
        rows = conn.execute(
            f'''SELECT
                  id, {name_column} AS name, address, description, category,
                  '' AS menu, '' AS hours, '' AS district,
                  TRIM(COALESCE(name, '')) AS source_name
                FROM restaurants
                WHERE TRIM(COALESCE({name_column}, '')) <> ''
                ORDER BY id'''
        ).fetchall()
    return {'lang': lang, 'items': [dict(row) for row in rows]}
@app.get('/api/restaurants/summary')
def restaurant_summary():
    with get_db() as conn:
        row = conn.execute("""
          SELECT COUNT(*) AS total, COUNT(DISTINCT NULLIF(TRIM(GUGUN_NM), '')) AS districts
          FROM external_data
          WHERE TRIM(COALESCE(UC_SEQ, '')) <> '' AND TRIM(COALESCE(LAT, '')) <> '' AND TRIM(COALESCE(LNG, '')) <> ''
        """).fetchone()
    return dict(row)
@app.post('/api/favorites/{restaurant_id}')
def add_favorite(restaurant_id: str):
    with get_db() as conn:
        exists = conn.execute('SELECT 1 FROM external_data WHERE UC_SEQ = ?', (restaurant_id,)).fetchone()
        if not exists:
            raise HTTPException(status_code=404, detail='맛집을 찾을 수 없습니다.')
        conn.execute('INSERT OR IGNORE INTO favorites (restaurant_id) VALUES (?)', (restaurant_id,))
    return {'ok': True}
@app.delete('/api/favorites/{restaurant_id}')
def delete_favorite(restaurant_id: str):
    with get_db() as conn:
        conn.execute('DELETE FROM favorites WHERE restaurant_id = ?', (restaurant_id,))
    return {'ok': True}
@app.post('/api/searches')
def save_search(body: SearchBody):
    query = body.query.strip()
    if query:
        with get_db() as conn:
            conn.execute('INSERT INTO search_history (query) VALUES (?)', (query,))
    return {'ok': True}
@app.get('/api/preferences')
def preferences():
    with get_db() as conn:
        rows = conn.execute('SELECT key, value FROM preferences').fetchall()
    return {row['key']: row['value'] for row in rows}
@app.put('/api/preferences')
def save_preference(body: PreferenceBody):
    with get_db() as conn:
        conn.execute(
            'INSERT INTO preferences (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
            (body.key, body.value),
        )
    return {'ok': True}
