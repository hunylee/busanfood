# 부산 맛집 지도

부산광역시 맛집 데이터를 지도에서 탐색하는 React + FastAPI 앱입니다.

## 실행

```bash
npm install
npm run dev
```

백엔드는 별도 터미널에서 실행합니다.

```bash
python3 -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

> 실제 `data/app.db`는 공공데이터 원본을 포함하므로 저장소에 포함하지 않습니다.
