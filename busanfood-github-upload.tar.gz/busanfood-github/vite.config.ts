import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '^(/preview/[^/]+)?/api/': {
        target: 'http://127.0.0.1:8000',
        rewrite: (p) => p.replace(/^\/preview\/[^/]+/, ''),
      },
    },
  },
})
